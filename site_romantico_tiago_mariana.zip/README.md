
# Site Romântico - Tiago & Mariana

Este é o site romântico personalizado para você e a Mariana.

## Como usar

1. Coloque os arquivos na mesma pasta (index.html e aliancas-tribalistas.mp3).
2. Abra o arquivo `index.html` em qualquer navegador moderno (Chrome, Firefox, Edge, Safari).
3. Clique no botão para escolher até 4 fotos e veja-as na página.
4. Edite o texto romântico no campo indicado.
5. A música "Alianças" do Tribalistas será tocada em loop.

## Hospedagem no GitHub Pages

1. Crie uma conta no [GitHub](https://github.com).
2. Crie um novo repositório público.
3. Faça upload do arquivo `index.html` e do arquivo `aliancas-tribalistas.mp3`.
4. Vá em **Settings > Pages** e ative a hospedagem escolhendo a branch principal (main/master).
5. Acesse o link gerado para ver seu site online.

---

**Nota:** Por questões de direitos autorais, o arquivo da música não está incluído aqui. Você deve obter o MP3 legalmente e adicionar na mesma pasta do `index.html` com o nome exato `aliancas-tribalistas.mp3`.
